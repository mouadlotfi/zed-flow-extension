def main():
    print("Hello from zed-flow-extenstion!")


if __name__ == "__main__":
    main()
